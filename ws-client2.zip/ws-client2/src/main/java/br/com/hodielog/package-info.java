@javax.xml.bind.annotation.XmlSchema(namespace = "http://hodielog.com.br/")
package br.com.hodielog;
